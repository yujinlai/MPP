package lesson7.labs.prob4;

public class RedheadDuck implements DuckBehavior {
}
