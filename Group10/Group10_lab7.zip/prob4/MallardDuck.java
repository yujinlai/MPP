package lesson7.labs.prob4;

public class MallardDuck implements DuckBehavior {
}
