package lesson6.labs.prob3;
public class DomException extends Exception {
	
	public DomException() {
		super();
	}
	
	public DomException(String s) {
		super(s);
	}

}

