package lesson3.labs.prob4;

public abstract class Property {
	public double computeRent() {
		return 0.0;
	};
}

